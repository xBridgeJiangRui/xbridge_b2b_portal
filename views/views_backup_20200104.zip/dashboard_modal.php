<?php
$customer_guid = $this->session->userdata('customer_guid');
$user_guid = $this->session->userdata('user_guid');

$this->db->query("SET @customer_guid = '$customer_guid'");
$this->db->query("SET @user_guid = '$user_guid'");
;?>

<!--  @@@@@@@@@@@@@@@@@@@@@@ Start Register Supplier modal @@@@@@@@@@@@@@@@ -->
<div class="modal fade" id="selected_modal2" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
                <h3 class="modal-title">Acceptance</h3>
            </div>
            <div class="modal-body form">
                <form action="<?php echo site_url('CusAdmin_controller/acknowledge') ?>" method="POST" id="form" class="form-horizontal">
                      <div class="form-body">
                        <div class="form-group">
                            <input type="hidden" name="announcement_guid" id="announcement_guid"/> 
                            <input type="hidden" name="user_guid" id="user_guid"/>  
                            <div class="col-md-9">
                            <textarea name="content" rows="10" cols="30" class="form-control" disabled></textarea>
                            </div>
                        </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                      <!-- <button type="submit" id="sendButton" class="btn btn-sm btn-primary">I AGREE</button> -->
                      <button type="button" class="btn btn-sm btn-default" data-dismiss="modal" >Cancel</button>
                  </div>
                </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--  @@@@@@@@@@@@@@@@@@@@@@@@@@@@ End Register Supplier modal @@@@@@@@@@@@@@@@@@@@@@@@@ -->
<!--  @@@@@@@@@@@@@@@@@@@@@@ Start Register Supplier modal @@@@@@@@@@@@@@@@ -->
<div class="modal fade" id="auto_modal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
                <h3 class="modal-title">Acceptance Form</h3>
            </div>
            <form action="<?php echo site_url('CusAdmin_controller/acknowledge') ?>" method="POST" id="form" class="form-horizontal">
            <div class="modal-body form">
                
                      <div class="form-body">
                        <div class="form-group">

                          <?php foreach($check_announcement_acknowledgement->result() as $row){ ?>
                            <input type="hidden" name="announcement_guid" id="announcement_guid" value="<?php echo $row->announcement_guid ?>"/> 
                            <input type="hidden" name="user_guid" id="user_guid" value='<?php echo $_SESSION['user_guid'] ?>'/>  

                            <?php if ($pdf == 1) { ?>

                              <div class="col-sm-12">
                                 <?php
                                 $i = 1;
                                 foreach($file_name_array as $row1)
                                 {
                                  ?>
                                    <embed src="<?php echo $virtual_path.'/acceptance_form/'.$row1.'.pdf'; ?>" width="100%" height="500px" style="border: none;"/>
                                 <?php
                                 }
                                 ?>                      

                                
                              </div>
                            

                          <?php } else { ?>
                            
                            <div class="col-md-9">
                            <textarea name="content" rows="10" cols="30" class="form-control" disabled> <?php echo $row->content ?></textarea>
                            </div>
                          <?php } ?>

                          <?php } ?>
                        </div>
                    </div>
                  
                  </div>
                  <div class="modal-footer">
                    <?php if($check_announcement_acknowledgement->row('agree') == 1)
                    {
                    ;?>
                      <button type="submit" id="sendButton" class="btn btn-sm btn-primary">I AGREE</button>
                    <?php
                    }
                    else
                    {
                    ;?>
                      <a href="" class="btn btn-primary btn-flat">OK</a>
                    <?php
                    }
                    ?>
                      <a href="<?php echo site_url('login_c/logout')?>" class="btn btn-default btn-flat">Cancel</a>
                  </div>
                  </form>
                </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<div class="modal fade" id="selected_modal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
                <h3 class="modal-title">Acceptance Form</h3>
            </div>
            <div class="modal-body form">
                <form action="<?php echo site_url('CusAdmin_controller/acknowledge') ?>" method="POST" id="form" class="form-horizontal">
                  <input type="hidden" name="announcement_guid" id="announcement_guid" value="<?php echo $row->announcement_guid ?>"/> 
                            <input type="hidden" name="user_guid" id="user_guid" value='<?php echo $_SESSION['user_guid'] ?>'/> 
                      <div class="form-body">
                        <div id="selected_modal_embed" class="col-sm-12">

                        
                      </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                      <button type="button" class="btn btn-sm btn-default" data-dismiss="modal" >Close</button>
                  </div>
                </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--  @@@@@@@@@@@@@@@@@@@@@@@@@@@@ End Register Supplier modal @@@@@@@@@@@@@@@@@@@@@@@@@ -->






<!--  @@@@@@@@@@@@@@@@@@@@@@ Notification modal @@@@@@@@@@@@@@@@ -->
<div class="modal fade" id="notification_modal" role="dialog" style="overflow-y:auto;" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
                <h3 class="modal-title">Notification</h3>
            </div>
            <form action="<?php echo site_url('CusAdmin_controller/acknowledge') ?>" method="POST" id="form" class="form-horizontal">
            <div class="modal-body form" style="min-height: 300px;">

                <div class="row">
                  <div class="col-md-12">

                    <?php
                    if($notification->num_rows() > 0)
                    {
                    ?>

                    <ul class="nav nav-tabs">

                    <?php
                      $i=0;

                      foreach($notification->result() as $row)
                      {
                      ?>

                        <li class="<?= $i == 0 ? 'active' : '' ;?>" id="li_<?php echo $row->notification_guid;?>"><a id="id_<?php echo $row->notification_guid;?>" href="#tab_<?php echo $row->notification_guid;?>" data-toggle="tab" aria-expanded="<?= $i == 0 ? 'true' : 'false' ;?>"><?php echo $row->description;?></a></li>

                      <?php
                        $i++;
                      }
                      ?>
                      
                      </ul>
                    <?php
                    }
                    ?>
                    


                    <div class="tab-content">

                    <?php

                    if($notification->num_rows() > 0)
                    {
                      $ii=0;

                      foreach($notification->result() as $row)
                      {
                      ?>

                        <div class="tab-pane fade in <?= $ii == 0 ? 'active' : '' ;?>" id="tab_<?php echo $row->notification_guid;?>">

                          <br>

                          <?php
                          $exec_query = str_replace("@user_mapped_loc",$this->session->userdata("query_loc"),$row->query);
                          $header = $this->db->query($exec_query.' LIMIT 1');

                          $array = $header->result();

                          $array = json_decode(json_encode($array));

                          if($header->num_rows() > 0)
                          {
                          ?>
                          

                          <table id="<?php echo $row->notification_guid;?>" class="table table-bordered table-hover">
                            <thead>
                              <tr>

                                <?php

                                

                                foreach($array[0] as $header => $value){
                                  echo "<th>".$header."</th>";
                                }

                                ?>

                              </tr>
                            </thead>
                          </table>
                        <?php  
                        }
                        else
                        {
                          echo "No Notification";
                        }
                        ?>
                        </div>

                      <?php
                        $ii++;
                      }

                      }
                      else
                      {
                        echo 'No Notification';
                      }
                      ?>

                    </div>
    

                  
                  </div>
                </div>

                  
            </div>
                  <div class="modal-footer">

                      <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Cancel</button>

                  </div>
                  </form>
                </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<div id="new-medium-modal" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>

      <div class="modal-body table-responsive modal-control-size">
        
      </div>

      <div class="modal-footer">
        <button type="button" id="new-medium-modal-close" class="btn btn-success" data-dismiss="modal">OK</button>
        
      </div>
    </div>
  </div>
</div>

<script>

$(document).ready(function(){
      $.ajax({
            url:"<?= site_url('Query_outstanding/get_outstanding');?>",
            method:"POST",
            dataType:'JSON',
            beforeSend:function(){
              // $('.btn').button('loading');
              $('.btn').prop('disabled',true);
            },
            success:function(data)
            {   
              
              if(data.result > '0')
              {
                var modal = $('#new-medium-modal').modal();

                modal.find(".modal-title").html('Reminder');              

                modal.find(".modal-body").html(data.string);
                if(data.force_logout == 1)
                {
                  modal.find(".modal-footer").html('<a href="<?php echo site_url('login_c/logout')?>" class="btn btn-default btn-flat">Close</a>'); 
                  modal.find(".modal-header").html('');
                } 
              }
              else
              {
                  <?php
                  if($check_announcement_acknowledgement->num_rows() > 0)
                  {
                  ?>
                  var mandatory = "<?php echo $mandatory;?>";

                     if(mandatory == 1)
                      {
                        
                        $('#auto_modal').attr({
                          "data-backdrop":"static",
                          "data-keyboard":"false"
                        });

                        var modal = $('#auto_modal').modal();

                        modal.find('a').prop('href','login_c/logout');

                      }
                      else
                      {

                        $('#auto_modal').removeAttr("data-backdrop");
                        $('#auto_modal').removeAttr("data-keyboard");


                        var modal = $('#auto_modal').modal();

                        modal.find('a').removeAttr("href");
                        modal.find('a').attr('data-dismiss','modal');

                      }//close else

                  <?php
                  }
                  else
                  {
                  ?>
                    
                    notification_table();
                  <?php
                  }
                  ?>
  
              }

             
              $('.btn').prop('disabled',false);
            }//close succcess
          });//close ajax

  <?php
  if($check_announcement_acknowledgement->num_rows() > 0)
  {
  ?>
    $(document).on('hide.bs.modal','#auto_modal',function(){

  <?php
  }
  ?>
  
  <?php
  if($check_announcement_acknowledgement->num_rows() <= 0)
  {
  ?>
    $(document).on('hide.bs.modal','#new-medium-modal',function(){

  <?php
  }
  ?>

  <?php
  if(in_array('VMN',$_SESSION['module_code']))
  {
      echo "var modal = $('#notification_modal').modal();";
  };
  ?>

    setTimeout(function(){

    <?php

    if($notification->num_rows() > 0)
    {

    foreach($notification->result() as $row)
    {
      $exec_query = str_replace("@user_mapped_loc",$this->session->userdata("query_loc"),$row->query);
      $header = $this->db->query($exec_query.' LIMIT 1');

      $array = $header->result();

      $array = json_decode(json_encode($array));

      if($header->num_rows() > 0)
      {
    ?>
      
      $('#<?php echo $row->notification_guid;?>').DataTable({
        "columnDefs": [ {"targets": 0 ,"visible": false}],
        "serverSide": true,
        'processing'  : true,
        'paging'      : true,
        'lengthChange': true,
        'lengthMenu'  : [ [10, 25, 50, 9999999999999999], [10, 25, 50, "ALL"] ],
        'searching'   : true,
        'ordering'    : true,
        'order'       : [],
        'info'        : true,
        'autoWidth'   : false,
        "bPaginate": true,
        "bFilter": true,
        "sScrollY": "30vh", 
        "sScrollX": "100%", 
        "sScrollXInner": "100%", 
        "bScrollCollapse": true,
        "ajax": {
            "url": "<?php echo site_url('Notification/notification_table');?>",
            "type": "POST",
            "data" : {query:"<?php echo addslashes($row->query);?>"},
            // success:function(data){

            //   var recordsTotal = data['recordsTotal']
            //   alert(recordsTotal);

            // },
        },
        columns: [
                  <?php
                  foreach($array[0] as $header => $value){
                    echo '{ data: "'.$header.'"},';
                  }
                  ?>
                 ],
        dom: "<'row'<'col-sm-4'l><'col-sm-8'f>>rtip",
        // "pagingType": "simple",
        "fnCreatedRow": function( nRow, aData, iDataIndex ) {
          $(nRow).attr('RefNo', aData['RefNo']);
          $(nRow).attr('status', aData['status']);
          $(nRow).attr('postdatetime', aData['postdatetime']);
        },
        "initComplete": function( settings, json ) {
        }
      });//close datatable

      $('div.dataTables_filter input').off('keyup.DT input.DT');

      var searchDelay = null;
         
      $(document).off('keyup','div.dataTables_filter input').on('keyup','div.dataTables_filter input', function(e) {
          var search = $(this).val();
          if (e.keyCode == 13) {
            var id = $(this).attr('aria-controls');
            $('#'+id).DataTable().search(search).draw();
          }//close keycode
      });//close keyup function

    <?php
    }//close foreach
      }//close if query header
    }//close if notification
    ?>

  },500);//clsoe settimeout

  
<?php
  if($check_announcement_acknowledgement->num_rows() <= 0)
  {
  ?>
    });

  <?php
  }
  ?>



  <?php
  if($check_announcement_acknowledgement->num_rows() > 0)
  {
  ?>
    });//close check auto_modal hide  
  <?php
  }
  else
  {
  ?>

<?php
  }
  ?>


  $(document).on('shown.bs.tab','a[data-toggle="tab"]', function (e) {
        // var target = $(e.target).attr("href"); // activated tab
        // alert (target);
        setTimeout(function () {
        $($.fn.dataTable.tables( true ) ).DataTable().columns.adjust()
        }, 100)
        // $($.fn.dataTable.tables( true ) ).DataTable().columns.adjust()
    } ); 

});//close check document ready




notification_table = function()
{
    <?php
  if(in_array('VMN',$_SESSION['module_code']))
  {
      echo "var modal = $('#notification_modal').modal();";
  };
  ?>

    setTimeout(function(){

    <?php

    if($notification->num_rows() > 0)
    {

    foreach($notification->result() as $row)
    {
      $exec_query = str_replace("@user_mapped_loc",$this->session->userdata("query_loc"),$row->query);
      $header = $this->db->query($exec_query.' LIMIT 1');

      $array = $header->result();

      $array = json_decode(json_encode($array));

      if($header->num_rows() > 0)
      {
    ?>
      
      $('#<?php echo $row->notification_guid;?>').DataTable({
        "columnDefs": [ {"targets": 0 ,"visible": false}],
        "serverSide": true,
        'processing'  : true,
        'paging'      : true,
        'lengthChange': true,
        'lengthMenu'  : [ [10, 25, 50, 9999999999999999], [10, 25, 50, "ALL"] ],
        'searching'   : true,
        'ordering'    : true,
        'order'       : [],
        'info'        : true,
        'autoWidth'   : false,
        "bPaginate": true,
        "bFilter": true,
        "sScrollY": "30vh", 
        "sScrollX": "100%", 
        "sScrollXInner": "100%", 
        "bScrollCollapse": true,
        "ajax": {
            "url": "<?php echo site_url('Notification/notification_table');?>",
            "type": "POST",
            "data" : {query:"<?php echo addslashes($row->query);?>"},
            // success:function(data){

            //   var recordsTotal = data['recordsTotal']
            //   alert(recordsTotal);

            // },
        },
        columns: [
                  <?php
                  foreach($array[0] as $header => $value){
                    echo '{ data: "'.$header.'"},';
                  }
                  ?>
                 ],
        dom: "<'row'<'col-sm-4'l><'col-sm-8'f>>rtip",
        // "pagingType": "simple",
        "fnCreatedRow": function( nRow, aData, iDataIndex ) {
          $(nRow).attr('RefNo', aData['RefNo']);
          $(nRow).attr('status', aData['status']);
          $(nRow).attr('postdatetime', aData['postdatetime']);
        },
        "initComplete": function( settings, json ) {
        }
      });//close datatable

      $('div.dataTables_filter input').off('keyup.DT input.DT');

      var searchDelay = null;
         
      $(document).off('keyup','div.dataTables_filter input').on('keyup','div.dataTables_filter input', function(e) {
          var search = $(this).val();
          if (e.keyCode == 13) {
            var id = $(this).attr('aria-controls');
            $('#'+id).DataTable().search(search).draw();
          }//close keycode
      });//close keyup function

    <?php
    }//close foreach
      }//close if query header
    }//close if notification
    ?>

  },500);//clsoe settimeout
}

</script>
