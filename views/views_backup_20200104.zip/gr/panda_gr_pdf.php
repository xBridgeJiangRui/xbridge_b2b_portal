<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper" >
<div class="container-fluid">
<br>
  <?php
  if($this->session->userdata('message'))
  {
    ?>
    <div class="alert alert-success text-center" style="font-size: 18px">
    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
  <button type="button" class="close" data-dismiss="alert"><i class="fa fa-remove"></i></button><br>
  </div>
    <?php
  }
  ?>

  <?php
  if($this->session->userdata('warning'))
  {
    ?>
    <div class="alert alert-danger text-center" style="font-size: 18px">
    <?php echo $this->session->userdata('warning') <> '' ? $this->session->userdata('warning') : ''; ?>
  <button type="button" class="close" data-dismiss="alert"><i class="fa fa-remove"></i></button><br>
  </div>
    <?php
  }
  ?>
<div class="col-md-12">
       <a class="btn btn-app" href="<?php echo site_url($_SESSION['frommodule'])?>?loc=<?php echo $_REQUEST['loc']; ?>&status=<?php echo $_SESSION['check_status']; ?>">
          <i class="fa fa-search"></i> Browse
        </a>
        <a class="btn btn-app" href="<?php echo site_url('login_c/location')?>">
          <i class="fa fa-bank"></i> Outlet
        </a>

        <?php if($paybyinvoice_got_grda == '0' && $accpt_gr_status != 'Confirmed' && $accpt_gr_status != 'confirmed')//pay by invoice
        {
          $einv_filename =ltrim($xcheck_einv_filepath, '/');
          if(file_exists($einv_filename))
          { 
        ?>
<!--             <button title="Confirm"  onclick="confirm_modal2('<?php echo site_url('general/confirm'); ?>?refno=<?php echo $_REQUEST['trans'] ?>&customer_guid=<?php echo $_SESSION['customer_guid'] ?>&table=grmain&col_guid=refno&loc=<?php echo $_REQUEST['loc'] ?>')" 
              type="button" class="btn btn-app" style="color:#008D4C"  data-toggle="modal" data-target="#confirm_gr" data-name="<?php echo $_REQUEST['trans'] ?>" >
                            <i class="fa fa-check"></i>Confirm GR
            </button> -->
       <?php
          }
        }
        ?>

        <?php if($paybyinvoice_got_grda == '1' && $get_DN_detail->num_rows() > 0 && $accpt_gr_status != 'Confirmed' && $accpt_gr_status != 'confirmed')//pay by invoice
        {
          $ecn_status = '';
          foreach($get_DN_detail->result() as $row2)
          {
            if($row2->ecn_guid == 'Pending') 
            {
              //echo 'Generates e-CN';
              $ecn_status .= '1';
            }
            // if($row2->ecn_guid != 'Pending' && $row->posted == '0') 
            // {
            //   echo 'Regenerate e-CN';
            // }
            // if($row2->ecn_guid != 'Pending') 
            // {
            //   echo 'View E-CN';
            // }
          }
          if($ecn_status == '' || $ecn_status == null)
          {
          ?>
<!--           <button title="Confirm"  onclick="confirm_modal2('<?php echo site_url('general/confirm'); ?>?refno=<?php echo $_REQUEST['trans'] ?>&customer_guid=<?php echo $_SESSION['customer_guid'] ?>&table=grmain&col_guid=refno&loc=<?php echo $_REQUEST['loc'] ?>')" 
          type="button" class="btn btn-app" style="color:#008D4C"  data-toggle="modal" data-target="#confirm_gr" data-name="<?php echo $_REQUEST['trans'] ?>" >
                        <i class="fa fa-check"></i>Confirm GR
        </button> -->
          <?php
          }
        }
        ?>

        <?php if($_SESSION['frommodule'] == 'panda_gr' &&$get_DN_detail->num_rows() == 0 && $paybyinvoice_got_grda == '1' && $accpt_gr_status != 'Confirmed' && $accpt_gr_status != 'confirmed') 
          { 
        ?>
<!--         <button title="Confirm"  onclick="confirm_modal2('<?php echo site_url('general/confirm'); ?>?refno=<?php echo $_REQUEST['trans'] ?>&customer_guid=<?php echo $_SESSION['customer_guid'] ?>&table=grmain&col_guid=refno&loc=<?php echo $_REQUEST['loc'] ?>')" 
          type="button" class="btn btn-app" style="color:#008D4C"  data-toggle="modal" data-target="#confirm_gr" data-name="<?php echo $_REQUEST['trans'] ?>" >
                        <i class="fa fa-check"></i>Confirm GR
        </button> -->
        <?php 
          } 
        ?>
  </div>

<!-- panel 1 -->
  <div class="row">
  <div class="col-md-12">
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title"><?php echo 'Header Detail '; ?></h3><br>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
          </div>
        </div>
      <div class="box-body">
        <div class="col-md-12">
            <div class="col-md-12"  style="overflow-x:auto;overflow-y:auto"> 
                  <div style="overflow-x:auto;">
                    <table id="smstable" class="tablesorter table table-striped table-bordered table-hover"> 
                      <form method="post" action="<?php echo site_url('panda_gr/edit_gr_header?refno='.$_REQUEST['trans'].'&loc='.$_REQUEST['loc'] ); ?>" id="form_EGRH" name="form_EGRH" >
                        <thead>
                        <tr>
                          <th>Refno</th>
                          <th>Inv No</th>
                          <th>Do No</th>
                          <th>Inv Date</th>
                          <th>GR Date</th>
                          <th>Total Exc Tax</th>
                          <th>Tax</th>
                          <th>Total Inc Tax</th>
                          <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $h = 0;
                        foreach($check_header->result() as $row)
                        {
                          $h++;
                          ?>
                          <tr>
                            <td><?php echo $row->RefNo?>
                            <input type="hidden" name="line[]" value="<?php echo $h?>">
                            </td>
                            <td data-toggle="tooltip" data-placement="bottom" title="<?php echo $row->InvNo?>">
                            <input class="form-control" type="text" readonly name="invno" value="<?php echo $row->InvNo?>">
                            <input  class="form-control" type="<?php echo $hidden_text ?>" name="ext_invno[]" value="<?php echo $row->InvNo?>" autocomplete="off">
                            </td>

                            <td data-toggle="tooltip" data-placement="bottom" title="<?php echo $row->DONo?>">
                            <input class="form-control" type="text" readonly name="dono" value="<?php echo $row->DONo?>">
                            <input class="form-control" type="<?php echo $hidden_text ?>" name="ext_dono[]" value="<?php echo $row->DONo?>" autocomplete="off"> 
                            </td>

                            <td  data-toggle="tooltip" data-placement="bottom" title="<?php echo $row->DocDate?>">
                            <input class="form-control" type="text" readonly name="docdate[]" value="<?php echo $row->DocDate?>"> 
                            <input class="form-control" type="<?php echo $hidden_text ?>" name="ext_docdate[]" placeholder="YYYY-MM-DD" value="<?php echo $row->DocDate?>" autocomplete="off"> 
                            </td> 

                            <td data-toggle="tooltip" data-placement="bottom" title="<?php echo $row->GRDate?>">
                            <input class="form-control" type="text" readonly name="grdate" value="<?php echo $row->GRDate ?>">
                            <input class="form-control" type="hidden" name="ext_grdate[]" value=""> 
                            </td>

                            <td style="text-align: right">
                              <?php echo number_format($row->Total,2)?></td>
                            <td style="text-align: right"><?php echo number_format($row->gst_tax_sum,2)?></td>
                            <td style="text-align: right"><?php echo number_format($row->total_include_tax,2)?></td>
                            <td>
                              <?php if($check_header->row('status') == '' || $check_header->row('status') == 'viewed' || $check_header->row('status') == 'printed' || $check_header->row('status') == 'Invoice Generated') { ?>
                              <a href="<?php echo $edit_header_url ?>" class="btn btn-xs btn-primary" ><i class="glyphicon glyphicon-edit"></i> Edit</a>
                              <?php } ?>

                              <?php if(isset($_REQUEST['edit'])) { ?>
                              <button class="btn btn-xs btn-success" onclick="$('#form_EGRH').submit()">Save </button>
                            <?php } ?>
                            </td>
                            </tr>
                          <?php
                        }
                        ?>
                        </tbody>
                          <input type="hidden" name="header_refno" value="<?php echo $_REQUEST['trans']?>">  
                          <input type="hidden" name="header_loc" value="<?php echo $_REQUEST['loc']?>">                                
                      </form>
                    </table>
<!-- original is $paybyinvoice_got_grda == '1' -->
                  <?php if($paybyinvoice_got_grda == '0') { ?>
                    <?php if($get_DN_detail->num_rows() > 0) {
                     ?>
                    
                    <table id="smstable" class="tablesorter table table-striped table-bordered table-hover"> 
                    <form  method="post" id="form_ECN" name="form_ECN" >
                       <input type="hidden" name="index_no" id="index_no">
                        <thead>
                        <tr>
                          <th>GRDA DN Refno</th>
                          <th>Type</th>
                          <th>Sup CN No.</th>
                          <th>Sup CN Date</th>
                          <th>Variance Amount</th>
                          <th>Tax Amount</th>
                          <th>Total Incl Tax</th>
                          <th>Action</th>
                          <?php
                          if($check_upload_grn_cn == 1)
                          {
                          ?>
                          <th>Uploaded Document</th>
                          <?php
                          }
                          ?>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                          $i = 0;
                        foreach($get_DN_detail->result() as $row)
                        {

                          ?>
                            <tr>
                              <td><?php echo $row->RefNo?></td>
                              <td data-toggle="tooltip" data-placement="top"
                                <?php if($row->transtype == 'GQV'){ ?>
                                  title="Variance in Qty"
                                <?php } elseif($row->transtype == 'IAV') { ?> 
                                  title="Variance in Cost"
                                <?php } elseif($row->transtype == 'GRV') { ?> 
                                  title="Rebate Value"
                                <?php } else { } ?> 
                              >
                                  <?php echo $row->transtype ?>
                                  
                              </td>
                              <!-- ori $row->posted == '1' -->
                              <td><input class="form-control" type="text" name="ext_doc1[]" value="<?php echo $row->ext_doc1 ?>" id="ext_sup_cn_no<?php echo $i;?>" required autocomplete="off" <?php if($row->ecn_guid != 'Pending') { echo 'readonly' ;} ?>  ></td>
                              <td><input class="form-control" type="text" name="ext_date1[]" value="<?php echo $row->ext_date1 ?> " required autocomplete="off" <?php if($row->ecn_guid != 'Pending') { echo 'readonly' ;} ?> > </td>
                              <td style="text-align: right"><?php echo number_format($row->VarianceAmt,2)?></td>
                              <td style="text-align: right"><?php echo number_format($row->gst_tax_sum,2)?></td>
                              <td style="text-align: right"><?php echo number_format($row->VarianceAmt+$row->gst_tax_sum,2)  ?></td>
                              <td>
                                <!-- for new and havent generate e_cn -->
                                <?php if($row->ecn_guid == 'Pending') 
                                  {
                                ?>
                                <?php
                                if($row->file_path != '')
                                {
                                ?>
                                          <button type="button" value="<?php echo $i;?>" class="index_get btn btn-xs btn-success" RefNo="<?php echo $row->RefNo?>" transtype="<?php echo $row->transtype;?>"  >Generates e-CN</button>
                                <?php
                                }
                                else
                                {
                                ?>
                                          <button type="button" class="btn btn-xs btn-success"  onclick="alert('Please Upload Supplier CN attachment first')"  >Generates e-CN</button>
                                <?php
                                }
                                ;?>

                                <!-- <button type="button" value="<?php echo $i;?>" class="index_get btn btn-xs btn-success" RefNo="<?php echo $row->RefNo?>" transtype="<?php echo $row->transtype;?>"  >Generates e-CN</button> -->
                                <?php
                                if($check_upload_grn_cn == 1)
                                {
                                ?>
                                <button class="btn btn-xs btn-primary" type="button" id="upload_grn_cn_doc" refno="<?php echo $_REQUEST['trans'] ?>"transtype="<?php echo $row->transtype ?>">Upload Supplier CN</button>
                                <?php
                                }
                                ?>

                                <?php } ?>
                                <!-- END generate e_cn -->  
                                <!-- for update e_cn -->
                                <?php if($row->ecn_guid != 'Pending' && $row->posted == '0') 
                                  {
                                ?>
                                <!-- <button class="btn btn-xs btn-danger" onclick="$('#form_ECN').submit()"> -->
<!--                                   <button type="button" value="<?php echo $i;?>" class="index_get btn btn-xs btn-danger" RefNo="<?php echo $row->RefNo?>" transtype="<?php echo $row->transtype;?>"  RefNo="<?php echo $row->RefNo?>" transtype="<?php echo $row->transtype;?>" >
                                Regenerate e-CN</button> -->
                                <?php
                                if($check_upload_grn_cn == 1)
                                {
                                ?>
                                <button class="btn btn-xs btn-primary" type="button" id="upload_grn_cn_doc" refno="<?php echo $_REQUEST['trans'] ?>" transtype="<?php echo $row->transtype ?>">Upload Supplier CN</button>
                                <?php
                                }
                                ?>                                
                                <?php } ?>
                                <!-- END generate e_cn -->
                                <!-- for update e_cn -->
                                <?php if($row->ecn_guid != 'Pending') 
                                  {
                                ?>
                                <a target="_blank" href="<?php echo site_url('panda_gr/view_ecn?refno='.$row->RefNo.'&transtype='.$row->transtype) ?>" class="btn btn-xs btn-warning" ><i class="glyphicon glyphicon-eye-open"></i>View E-CN</a>
                                <?php } ?>

                                <!-- <?php if($row->ecn_guid != 'Pending') 
                                  {
                                ?>
                                <a target="_blank" href="<?php echo site_url('panda_gr/view_ecn?refno='.$row->RefNo.'&transtype='.$row->transtype) ?>" class="btn btn-xs btn-warning" ><i class="glyphicon glyphicon-heart"></i>new method E-CN</a>
                                <?php } ?> -->
                                <!-- END generate e_cn -->
                          <input type="hidden" name="gr_refno" value="<?php echo $_REQUEST['trans']?>">  
                          <input type="hidden" name="gr_loc" value="<?php echo $_REQUEST['loc']?>">                                
                          <input type="hidden" name="ecn_refno[]" value="<?php echo $row->RefNo?>"> 
                          <input type="hidden" name="ecn_type[]" value="<?php echo $row->transtype?>">
                          <input type="hidden" name="ecn_varianceamt[]" value="<?php echo $row->VarianceAmt?>"> 
                          <input type="hidden" name="ecn_tax_rate[]" value="<?php echo '0' ?>"> 
                          <input type="hidden" name="ecn_gst_tax_sum[]" value="<?php echo $row->gst_tax_sum?>"> 
                          <input type="hidden" name="ecn_total_incl_tax[]" value="<?php echo $row->VarianceAmt+$row->gst_tax_sum   ?>"> 
                          <input type="hidden" name="ecn_customer_guid[]" value="<?php echo $_SESSION['customer_guid'] ?>">
                          <input type="hidden" name="ecn_loc[]" value="<?php echo $_REQUEST['loc'] ?>"> 
                          
                          <input type="hidden" name="ecn_rows[]" value="<?php echo $row->rowx ?>">
                           
                              </td>
                          <?php 
                          if($check_upload_grn_cn == 1)
                          {
                          if($row->file_path != '')
                          {
                          ?>
                          <td>Uploaded <a target="_blank" href="<?php echo base_url($row->file_path).'?time='.date("Ymdhs");?>"><button class="btn btn-xs btn-success" type="button"">View Supplier CN</button></a></td>
                          <?php
                          }
                          else
                          {
                          ?>
                          <td>Not Upload</td>
                          <?php  
                          }
                          }
                          ?>                              
                            </tr>
                          <?php
                      $i++;
                    }
                        ?>
                           </form>
                        </tbody>
                    </table>
                  <?php }  // close of first loop
                } // close the paybyinvoice flag
                ?>
                  </div> 
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php //  echo $paybyinvoice_got_grda ?>
<?php // echo var_dump($aaa) ?>
<!--  panel 2 -->
<?php if($paybyinvoice_got_grda == '0' && $open_panel3 == '1'){ ?>
<div class="row" >
  <div class="col-md-12">
      <div class="box box-default <?php echo $open_panel2 ?>">
        <div class="box-header with-border">
          <h3 class="box-title"><?php echo 'Item Detail'; ?></h3> 
           
          <div class="box-tools pull-right " style="display: inline-flex;">
            <?php
              if ($child_result_validation >= '1')
              {
                if($get_DN_detail->num_rows() > 0)
                {
                  if($check_ecn_main->num_rows() > 0)
                  {
            ?>
                      <button class="btn btn-xs btn-success" onclick="$('#formSBNC').submit()"   ><i class="glyphicon glyphicon-floppy-saved"></i>  Generate E-Invoice</button><br>
            <?php 
                  }
                  else
                  {
            ?>
                      <button class="btn btn-xs btn-success" onclick="alert('Please Generate E-CN first and confirm your supplier cn number')"   ><i class="glyphicon glyphicon-floppy-saved"></i>  Generate E-Invoice</button><br>
            <?php
                  }
                }
                else
                {
            ?>
                  <button class="btn btn-xs btn-success" onclick="$('#formSBNC').submit()"   ><i class="glyphicon glyphicon-floppy-saved"></i>  Generate E-Invoice</button><br>
            <?php
                }
              } 
            ?>
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="<?php echo $item_detail_icon ?>"></i></button>
          </div>
        </div>
      <div class="box-body">
            <div class="col-md-12"  style="overflow-x:auto;overflow-y:auto"> 
              <form method="post" action="<?php echo site_url('panda_gr/supplier_check?trans='); ?><?php echo $_REQUEST['trans'] ?>" id="formSBNC" name="formSBNC" >
                 <div style="overflow-x:auto;">
                    <table id="smstable" class="tablesorter table table-striped table-bordered table-hover"> 
                        <thead>
                        <tr>
                          <th>No.</th>
                          <th>Itemcode/<br>barcode</th>
                          <!-- <th>Barcode</th> -->
                          <th>Description</th>
                          <th>PS / Ctn Qty</th>
                          <th>Unit Price Before Disc</th>
                          <!-- requested to close as requestedby Mr.Loo
                            <th>Item Disc Description</th> 
                          -->
                          <th>Item Disc</th>
                          <th>Total Bill Disc Prorated</th>
                          <th>Unit Price After Disc</th>
                          
                          <th>Received Quantity</th>
                          <th>Invoice Qty</th>
                          <th>Invoice Unit Cost</th>
                          <th style="color:red;display:none"><input type="checkbox" onClick="selectall_activate(this);"   />Supplier Check  </th>

                          <th>Total Amount Excl Tax</th>
                          <!-- <th>Total Tax Amount</th> -->
                          <th>Total Amount Incl Tax</th>
                          <th>GRDA Type</th>
                          <th>Variance Amount</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if ($child_result_validation >= '1')
                        {
                          foreach($check_child as $row => $value)
                        {
                          ?>
                            <tr>
                              <td><?php echo $value['line']?>
                                <input type="hidden" name="line[]" value="<?php echo $value['line'] ?>">
                              </td>
                              <td><?php echo $value['itemcode']?>
                                <input type="hidden" name="itemcode[]" value="<?php echo $value['itemcode'] ?>">/<br><?php echo $value['barcode']?>
                                 <input type="hidden" name="barcode[]" value="<?php echo $value['barcode'] ?>">
                              </td>
                              <!-- <td><?php echo $value['barcode']?>
                                 <input type="hidden" name="barcode[]" value="<?php echo $value['barcode'] ?>">
                              </td> -->
                              <td><?php echo $value['description']?>
                                <input type="hidden" name="description[]" value="<?php echo $value['description'] ?>">
                              </td>
                              <td><?php echo $value['packsize']; ?>
                                <input type="hidden" name="packsize[]" value="<?php echo $value['packsize'] ?>">
                              </td>
                              <td style="text-align: right"><?php echo  number_format($value['unitprice'],2)?>
                                <input type="hidden" name="unitprice[]" value="<?php echo $value['unitprice'] ?>">
                              </td>
                              <!--  requested to close
                              <td><?php echo $value['disc_desc']?> -->
                                <input type="hidden" name="disc_desc[]" value="<?php echo $value['disc_desc'] ?>">
                              <!-- </td>  -->
                             
                              <td style="text-align: right"><?php echo number_format($value['discamt'],2)?>
                                <input type="hidden" name="discamt[]" value="<?php echo $value['discamt'] ?>">
                              </td>
                              <td style="text-align: right"><?php echo number_format($value['unit_disc_prorate'],2)?>
                                <input type="hidden" name="unit_disc_prorate[]" value="<?php echo $value['unit_disc_prorate'] ?>">
                              </td>
                              <td style="text-align: right"><?php echo number_format($value['unit_price_bfr_tax'],2)?>
                                <input type="hidden" name="unit_price_bfr_tax[]" value="<?php echo $value['unit_price_bfr_tax'] ?>">
                              </td>
                              
                              <td><?php echo $value['qty'];echo ' '; echo $value['um'];?>
                                <input type="hidden" name="qty[]" value="<?php echo $value['qty'] ?>">
                                <input type="hidden" name="um[]" value="<?php echo $value['um'] ?>">
                              </td>
                              <td><?php echo $value['inv_qty'];echo ' '; echo $value['um'];?></td>
                              <td style="text-align: right"><?php echo number_format($value['inv_unitprice'],2);?></td>
                              <td style="display:none">
                                <input type="checkbox" name="supcheck[]" class="ahshengcheckbox"  value='1'  >
                                <input type='hidden' name='supcheck2[]' class="hiddencheckbox" value='0'> 
                              </td>

                              <td style="text-align: right"><?php echo number_format($value['totalprice'],2)?>
                                <input type="hidden" name="totalprice[]" value="<?php echo $value['totalprice'] ?>"> 
                              </td>
                              <!-- <td style="text-align: right"><?php echo number_format($value['gst_tax_amount'],2)?>-->
                                <input type="hidden" name="gst_tax_amount[]" value="<?php echo $value['gst_tax_amount'] ?>">
                              </td> 
                              <td style="text-align: right"><?php echo number_format($value['gst_unit_total'],2)?>
                                <input type="hidden" name="gst_unit_total[]" value="<?php echo $value['gst_unit_total'] ?>">
                              </td>
                              <td style="text-align: right"><?php echo  $value['grda_type'] ?>
                                
                              </td>
                              <td style="text-align: right"><?php echo  $value['grda_remark']?>
                                
                              </td>
                            </tr>
                          <?php
                        }  
                      }
                      else
                      {
                        echo 'Child Data Not Found';
                      }
                        ?>
                        </tbody>
                      </table>
                    </div> 

                    <?php
                        foreach($check_header->result() as $row)
                        {
                          ?>
                            <input type="hidden" name="location" value="<?php echo $_REQUEST['loc'] ?>">
                            <input type="hidden" name="branch_code" value="<?php echo $row->Location ?>">
                              <input type="hidden" name="H_refno" value="<?php echo $row->RefNo?>">
                              <input type="hidden" name="H_invno" value="<?php echo $row->InvNo ?>">
                              <input type="hidden" name="H_dono" value="<?php echo $row->DONo ?>">
                              <input type="hidden" name="H_docdate" value="<?php echo $row->DocDate ?>">
                              <input type="hidden" name="H_grdate" value="<?php echo $row->GRDate?>">
                              <input type="hidden" name="H_total" value="<?php echo $row->Total ?>"> 
                              <input type="hidden" name="H_gst_tax_sum" value="<?php echo $row->gst_tax_sum ?>">
                              <input type="hidden" name="H_total_include_tax" value="<?php echo $row->total_include_tax ?>">
                             
                          <?php
                        }
                        ?>
            </div>
        </div>
      </div>
    </div>
  </div> 
<?php } ?>
<!-- panel 3 -->
<?php if($open_panel3 == '0') { ?>
 <div class="row">
    <div class="col-md-12">
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title"><?php echo 'E-Invoice Revise : [';echo $version; echo ']' ?></h3><br>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
          </div>
        </div>
      <div class="box-body">
        <?php // echo $check_einv_filepath ?>
        <div class="col-md-12" style="height: 500px;">
                 

          <?php 

            $ua = strtolower($_SERVER['HTTP_USER_AGENT']);


if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']), 'mobile') || strstr(strtolower($_SERVER['HTTP_USER_AGENT']), 'android')) { // && stripos($ua,'mobile') !== false) { ?>

<!--   <embed src="https://docs.google.com/gview?embedded=true&url=<?php echo $check_einv_filepath; ?>&amp;embedded=true" width="100%"  style="border: none;height:20em"/>  -->

    <embed src="<?php echo site_url('Panda_gr/fetch_e_invoice_pdf?trans=').$_REQUEST['trans']; ?>" width="100%" height="500px" style="border: none;"/> This browser does not support PDFs. Please download the PDF to view it: <a href="<?php echo $check_einv_filepath; ?>">Download PDF</a> 

<?php  } else { ?>
  
<!-- <embed src="<?php echo $check_einv_filepath; ?>" width="100%" height="500px" style="border: none;"/> This browser does not support PDFs. Please download the PDF to view it: <a href="<?php echo $check_einv_filepath; ?>">Download PDF</a>  -->
    <embed src="<?php echo site_url('Panda_gr/fetch_e_invoice_pdf?trans=').$_REQUEST['trans']; ?>" width="100%" height="500px" style="border: none;"/> This browser does not support PDFs. Please download the PDF to view it: <a href="<?php echo $check_einv_filepath; ?>">Download PDF</a> 

<?php } ?>


                
        </div>
      </div>

    </div>
</div>
</div>
 <?php } ?>
<!-- panel 4 -->
<div class="row">
    <div class="col-md-12">
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title"><?php  echo $title; ?></h3><br>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
          </div>
        </div>
      <div class="box-body">
        <div class="col-md-12">
                <div class="col-md-12"  style="overflow-x:auto;overflow-y:auto"> 

                            <?php 

            $ua = strtolower($_SERVER['HTTP_USER_AGENT']);


if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']), 'mobile') || strstr(strtolower($_SERVER['HTTP_USER_AGENT']), 'android')) {
// && stripos($ua,'mobile') !== false) { ?>

  <embed src="https://docs.google.com/gview?embedded=true&url=<?php echo $filename; ?>&amp;embedded=true" width="100%" style="border: none;height:20em"/> 

<?php  } else { ?>

<?php if($file_headers[0] != 'HTTP/1.1 404 Not Found') { ?>
                        <embed src="<?php echo $filename; ?>" width="100%" height="500px" style="border: none;"/> This browser does not support PDFs. Please download the PDF to view it: <a href="<?php echo $filename; ?>">Download PDF</a> 
                    <?php } else 
                        {  
                          echo 'pdf not found'; 
                        }
                    ?>


<?php } ?>
                    
                </div>
        </div>
      </div>

    </div>
</div>
</div>


<?php if($show_grda_pdf == '1'){ ?>
  <div class="row">
    <div class="col-md-12">
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title"><?php  echo 'GRDA'; ?></h3><br>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
          </div>
        </div>
      <div class="box-body">
        <div class="col-md-12">
                <div class="col-md-12"  style="overflow-x:auto;overflow-y:auto"> 


                  <?php 

            $ua = strtolower($_SERVER['HTTP_USER_AGENT']);


if(strstr(strtolower($_SERVER['HTTP_USER_AGENT']), 'mobile') || strstr(strtolower($_SERVER['HTTP_USER_AGENT']), 'android')) { // && stripos($ua,'mobile') !== false) { ?>

  <embed src="https://docs.google.com/gview?embedded=true&url=<?php echo $grda_filename; ?>&amp;embedded=true" width="100%" style="border: none;height:20em"/> 

<?php  } else { ?>

<?php if($grda_file_headers[0] != 'HTTP/1.1 404 Not Found') { ?>
                        <embed src="<?php echo $grda_filename; ?>" width="100%" height="500px" style="border: none;"/> This browser does not support PDFs. Please download the PDF to view it: <a href="<?php echo $grda_filename; ?>">Download PDF</a> 
                    <?php } else 
                        {  
                          echo 'pdf not found'; 
                        }
                    ?>


<?php } ?>
                    
                </div>
        </div>
      </div>

    </div>
</div>
</div>
<?php } ?>






</div>
</div>

<script type="text/javascript">
  function form_submit(refno , type)
  { 

// var para = [];

//       $('input[name="ext_doc1[]"]').each(function() {

//       if(($(this).val() == '') || ($(this).val() == ' ') || ($(this).val() == null))
//       {  
//         para.push('1');
//       }
//       else
//       {
//         para.push('0');
//       }
//   });

// var uniqueArray = Array.from(new Set(para));

//   if(jQuery.inArray("1", uniqueArray) >= 0)
//   {
//       alert('canot null 1');
//       return;
//   }

// var para = [];

//   $('input[name="ext_date1[]"]').each(function() {
//       if(($(this).val() == '') || ($(this).val() == ' ') || ($(this).val() == null))
//       {  
//         para.push('1');
//       }
//       else
//       {
//         para.push('0');
//       }
//   });


// var uniqueArray = Array.from(new Set(para));

//   if(jQuery.inArray("1", uniqueArray) >= 0)
//   {
//       alert('canot null 2');
//       return;
//   }


    //window.location.reload();
    $("#form_ECN").attr("action", "<?php echo site_url('panda_gr/generate_ecn');?>?refno="+refno+"&transtype="+type);
    $("#form_ECN").attr("target", "_blank");
    $("#form_ECN").submit();
// window.location.reload();

  }

  function confirm_modal2(confirm_url)
  {
    $('#confirm_gr').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) 

    var modal = $(this)
    modal.find('.modal_detail').text('Confirm GR ' + button.data('name') + '?')
    document.getElementById('url_confirm').setAttribute("href" , confirm_url );
    });
  }

   function selectall_activate(source) {  
    activate = document.getElementsByName('supcheck[]');

    if(source.checked)
    {
      var valieber = '1';

    }else
    {
       var valieber = '0';
    }
    for(var i=0, n=activate.length;i<n;i++) {
      activate[i].checked = source.checked;
        $('.hiddencheckbox').eq(i).val(valieber); 
    }
  }
</script>
<script type="text/javascript">
  $(document).ready(function(){
     $('input[type=checkbox]').attr('checked',false);
    $( ".ahshengcheckbox" ).click(function() {
    var indes = $(".ahshengcheckbox").index(this);
    if($(this).is(':checked'))
    {
       $('.hiddencheckbox').eq(indes).val('1');
    }
    else
    {
       $('.hiddencheckbox').eq(indes).val(0);
    }
  
    });  
  })
  setTimeout(function(){
   // window.location.reload(true);
}, 30000);
</script>
<script type="text/javascript">
$(function() {
  $('input[name="ext_docdate[]"]').daterangepicker({
    locale: {
      format: 'YYYY-MM-DD'
    },
    singleDatePicker: true,
    showDropdowns: true,
    autoUpdateInput: true,
  });
 /* $(this).find('[name="ext_docdate[]"]').val("");*/
});
</script>
<script type="text/javascript">
$(function() {
  $('input[name="ext_date1[]"]').daterangepicker({
    locale: {
      format: 'YYYY-MM-DD'
    },
    singleDatePicker: true,
    showDropdowns: true,
    autoUpdateInput: true,
  });/*
  $(this).find('[name="ext_date1[]"]').val("");*/
});

$(document).ready(function(){

    $(document).on('click','.index_get',function(){

      var index_no = $(this).val();

      $('#index_no').val(index_no);
      var refno = $(this).attr('RefNo');
      var type = $(this).attr('transtype');
      var ext_sup_cn_no = $('#ext_sup_cn_no'+index_no).val();
// alert(refno+type+'--'+ext_sup_cn_no+'2323');return;
      if(ext_sup_cn_no == '' || ext_sup_cn_no == null)
      {
        alert('Please Insert Supplier CN No');
        return;
      }
      if(refno == '' || refno == null)
      {
        alert('Refno Empty,Please Contact Admin');
        return;
      }
      if(type == '' || type == null)
      {
        alert('Trans Type Empty,Please Contact Admin');
        return;
      }

      $("#form_ECN").attr("action", "<?php echo site_url('panda_gr/generate_ecn');?>?refno="+refno+"&transtype="+type);
      // $("#form_ECN").attr("target", "_blank");
      $("#form_ECN").submit();

      // window.location.reload();

    });

    $(document).on('click','#upload_grn_cn_doc',function(){
      var refno = $(this).attr('refno');
      var doc_type = "<?php echo $_REQUEST['accpt_gr_status'];?>";
      var loc = "<?php echo $_REQUEST['loc'];?>";
      var transtype = $(this).attr('transtype');
      // alert(transtype);return;
      var modal = $("#medium-modal").modal();

      modal.find('.modal-title').html('Upload Supplier CN');

      methodd = '';
      methodd +='<form action="<?php echo site_url('Upload/upload_grn_cn');?>" method="post" enctype="multipart/form-data" id="form_upload_prdn_cn">';
      methodd +='<div class="col-md-12">';

      methodd += '<div class="col-md-6"><label>Refno</label><input type="text" id="add_refno" class="form-control input-sm" placeholder="Refno" style="text-transform:uppercase" value='+refno+' name="upload_cn_refno" readonly required/></div>';

      methodd += '<div class="col-md-6"><label>File (Only PDF allow)</label><input type="file" id="add_group_name" class="form-control input-sm" name="upload_grn_cn_doc" accept=".pdf" placeholder="Please Choose File" required/><input type="hidden" name="upload_prdn_cn_status" value="'+doc_type+'"/><input type="hidden" name="upload_prdn_cn_loc" value="'+loc+'"/><input type="hidden" name="upload_prdn_cn_transtype" value="'+transtype+'"/></div>';

      methodd += '</div>';
      methodd +='<input type="submit" id="upload_cn_doc_submit_button_hide" style="display:none;"></form>';

      methodd_footer = '<p class="full-width"><span class="pull-right"><input type="button" id="upload_cn_doc_submit_button" class="btn btn-success" value="Upload"> <input name="sendsumbit" type="button" class="btn btn-default" data-dismiss="modal" value="Close"> </span></p>';

      modal.find('.modal-footer').html(methodd_footer);
      modal.find('.modal-body').html(methodd);

    });

    $(document).on('click','#upload_cn_doc_submit_button',function(){
       // $("#form_upload_prdn_cn").submit();
       $("#upload_cn_doc_submit_button_hide").trigger('click');
    });    
});

</script>
