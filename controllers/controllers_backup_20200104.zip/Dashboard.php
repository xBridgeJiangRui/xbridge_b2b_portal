<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class dashboard extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('General_model');
        $this->load->library('form_validation');        
        $this->load->library('datatables');
         
    }

    public function index()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('userid') != '' && $_SESSION['user_logs'] == $this->panda->validate_login())
        {   
            if ($_SERVER['HTTPS'] !== "on") 
            {
            $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];   
            header("Location: $url");
            } 

            $location = $_SESSION['location'];
            $dashboard_num_days_data = $this->db->query("SELECT * FROM  acc where acc_guid = '".$_SESSION['customer_guid']."'")->row('dashboard_num_days_data');
            
            $iquery_loc = $_SESSION['query_loc'];

            if($iquery_loc == null || $iquery_loc == '')
            {
                $iquery_loc = "''";
            }

            if(!in_array('IAVA',$_SESSION['module_code']))
            {
                $check_outstanding_pomain = $this->db->query("SELECT count(refno) as count_pomain from b2b_summary.pomain where status = '' and customer_guid = '".$_SESSION['customer_guid']."' and loc_group in (".$_SESSION['query_loc'].") and scode in (".$_SESSION['query_supcode'].") and podate BETWEEN CURDATE() - INTERVAL $dashboard_num_days_data DAY AND CURDATE()");

                $check_grn =  $this->db->query("SELECT COUNT(refno) AS count_doc FROM b2b_summary.grmain WHERE STATUS = '' AND customer_guid = '".$_SESSION['customer_guid']."' AND loc_group IN (".$_SESSION['query_loc'].") AND CODE IN (".$_SESSION['query_supcode'].") AND grdate BETWEEN CURDATE() - INTERVAL $dashboard_num_days_data DAY AND CURDATE() ");

                // $check_grda =  $this->db->query("SELECT count(refno) as count_doc from b2b_summary.pomain where status = 'rejected' and customer_guid = '".$_SESSION['customer_guid']."' and loc_group in (".$_SESSION['query_loc'].") and scode in (".$_SESSION['query_supcode'].") and podate BETWEEN CURDATE() - INTERVAL $dashboard_num_days_data DAY AND CURDATE() ");

                $check_grda =  $this->db->query("SELECT COUNT(a.refno) AS count_doc FROM b2b_summary.grmain AS a INNER JOIN (SELECT * FROM b2b_summary.grmain_dncn WHERE customer_guid = '".$_SESSION['customer_guid']."' GROUP BY refno) AS b ON a.refno = b.refno AND a.customer_guid = b.customer_guid WHERE b.`customer_guid` = '".$_SESSION['customer_guid']."' AND a.loc_group IN (".$_SESSION['query_loc'].") and code in (".$_SESSION['query_supcode'].")  AND a.grdate BETWEEN CURDATE() - INTERVAL $dashboard_num_days_data DAY AND CURDATE() ");

                $no_respond =  $this->db->query("SELECT count(refno) as count_pomain from b2b_summary.pomain where status = '' and customer_guid = '".$_SESSION['customer_guid']."' and loc_group in (".$_SESSION['query_loc'].") and scode in (".$_SESSION['query_supcode'].") and podate < CURDATE() - INTERVAL $dashboard_num_days_data DAY and CURDATE() ");

                /* current alert include
                    - grmain header proposed [x]
                    - grmain reject item [ ]
                    - return reject proposed cost [ ]
                */

                //$alert = $this->db->query("SELECT COUNT(refno) as count_alert FROM b2b_summary.grmain_proposed  WHERE posted = '1' and customer_guid = '".$_SESSION['customer_guid']."' and location in (".$_SESSION['query_loc'].") and code in (".$_SESSION['query_supcode']."); ")->row('count_alert');


            }
            else
            {
                $check_outstanding_pomain = $this->db->query("SELECT count(refno) as count_pomain from b2b_summary.pomain where status = '' and customer_guid = '".$_SESSION['customer_guid']."' and location in ($iquery_loc)  and podate BETWEEN CURDATE() - INTERVAL $dashboard_num_days_data DAY AND CURDATE()");


                $check_grn =  $this->db->query("SELECT COUNT(refno) AS count_doc 
                    FROM b2b_summary.grmain WHERE STATUS = '' 
                    AND customer_guid = '".$_SESSION['customer_guid']."' AND location IN ($iquery_loc)  
                    AND grdate BETWEEN CURDATE() - INTERVAL $dashboard_num_days_data DAY AND CURDATE() ");

                // $check_grda =  $this->db->query("SELECT count(refno) as count_doc from b2b_summary.pomain where status = 'rejected' and customer_guid = '".$_SESSION['customer_guid']."' and location in ($iquery_loc) and podate BETWEEN CURDATE() - INTERVAL $dashboard_num_days_data DAY AND CURDATE() ");

                $check_grda =  $this->db->query("SELECT COUNT(a.refno) AS count_doc FROM b2b_summary.grmain AS a INNER JOIN (SELECT * FROM b2b_summary.grmain_dncn WHERE customer_guid = '".$_SESSION['customer_guid']."' GROUP BY refno) AS b ON a.refno = b.refno AND a.customer_guid = b.customer_guid WHERE b.`customer_guid` = '".$_SESSION['customer_guid']."' AND a.loc_group IN ($iquery_loc) AND a.grdate BETWEEN CURDATE() - INTERVAL $dashboard_num_days_data DAY AND CURDATE() ");

                $no_respond =  $this->db->query("SELECT count(refno) as count_pomain from b2b_summary.pomain where status = '' and customer_guid = '".$_SESSION['customer_guid']."' and location in ($iquery_loc) and podate < CURDATE() - INTERVAL $dashboard_num_days_data DAY and CURDATE() ");

                /* current alert include
                    - grmain header proposed [x]
                    - grmain reject item [ ]
                    - return reject proposed cost [ ]
                */ 

                $this->panda->set_global_variable();

                $alert = $this->db->query("SELECT COUNT(refno) as count_alert  FROM b2b_summary.grmain_proposed  WHERE posted = '0' and customer_guid = '".$_SESSION['customer_guid']."' and location in (SELECT branch_code from query_loc_".$_SESSION['user_guid'].")  ")->row('count_alert');

                //echo $this->db->last_query();die;
            };

            $check_announcement = $this->db->query("SELECT * from announcement where customer_guid = '".$_SESSION['customer_guid']."' and posted= '1' and now() >= publish_at and acknowledgement = 0 order by publish_at desc, created_at desc limit 1");

            if($check_announcement->num_rows() < 1)
            {
                $announcement = $this->db->query("SELECT 'Welcome' as title, 'No New announcement at this moment' as content, curdate() as docdate ");
               // echo $this->db->last_query();die;
            }   
            else
            {
                $announcement = $check_announcement;
            };

            // check if acknowledgement need to be alerted

            $check_announcement_acknowledgement = $this->db->query("SELECT a.* FROM lite_b2b.announcement AS a LEFT JOIN  (SELECT * FROM lite_b2b.announcement_child  WHERE  user_guid = '".$_SESSION['user_guid']."' ) AS b ON a.`announcement_guid` = b.`announcement_guid` WHERE a.`customer_guid` = '".$_SESSION['customer_guid']."' AND a.`acknowledgement` = '1' AND a.posted = '1' and b.announcement_guid_c is null ORDER BY a.`publish_at` DESC limit 1 ");
            // print_r($check_announcement_acknowledgement->result());die;

            if($check_announcement_acknowledgement->num_rows() >= 1)
            { 
                $show_panel = '1';
                $mandatory = $check_announcement_acknowledgement->row('mandatory');
                $pdf = $check_announcement_acknowledgement->row('pdf_status');
                $show_announcement_sidebar = $this->db->query("SELECT a.* ,b.created_at AS acknowledged_at FROM lite_b2b.announcement AS a LEFT JOIN  (SELECT * FROM lite_b2b.announcement_child  WHERE  user_guid = '".$_SESSION['user_guid']."' ) AS b ON a.`announcement_guid` = b.`announcement_guid` WHERE a.`customer_guid` = '".$_SESSION['customer_guid']."' AND a.`pdf_status` = '1' AND a.posted = '1' ORDER BY a.`publish_at` DESC ");
                
            }
            else
            {
                $show_panel = '0';
                $mandatory = $check_announcement_acknowledgement->row('mandatory');
                $pdf = $check_announcement_acknowledgement->row('pdf_status');
                $show_announcement_sidebar =  $this->db->query("SELECT a.* ,b.created_at AS acknowledged_at FROM lite_b2b.announcement AS a LEFT JOIN  (SELECT * FROM lite_b2b.announcement_child  WHERE  user_guid = '".$_SESSION['user_guid']."' ) AS b ON a.`announcement_guid` = b.`announcement_guid` WHERE a.`customer_guid` = '".$_SESSION['customer_guid']."' AND a.`pdf_status` = '1' AND a.posted = '1' ORDER BY a.`publish_at` DESC ");
            }
            // echo $this->db->last_query();die;
 
            $redirect_pomain = site_url('dashboard/redirect_from_dashboard?mode=panda_po_2&loc=HQ');
            $redirect_grmain = site_url('dashboard/redirect_from_dashboard?mode=panda_gr&loc=HQ');
            $redirect_grmain_download = site_url('dashboard/redirect_from_dashboard?mode=panda_gr_download&loc=HQ');
            $redirect_grda  = site_url('dashboard/redirect_from_dashboard?mode=panda_grda&loc=HQ');

            $virtual_path = $this->db->query("SELECT file_path FROM acc WHERE acc_guid = '".$_SESSION['customer_guid']."'")->row('file_path');

            if($pdf == 1)
            {
                $announcement_guid = $check_announcement_acknowledgement->row('announcement_guid');
                $file_name = $this->db->query("SELECT content FROM announcement WHERE announcement_guid = '$announcement_guid'");
                // print_r (explode("-+0+-",$file_name->row('content')));
                $file_name_array = explode("-+0+-",$file_name->row('content'));
                // print_r($file_name_array);die;
                
                // $data2 = array();
                // $i = 1;
                // foreach($file_name_array as $row)
                // {
                //     $aa = 'file_name'.$i;
                //     // $$aa = $row.'<br>';
                //     $data2[''.$$aa.''] = $row;
                //     $i++;
                // }
                // $count_array = count($file_name_array);
                // // echo $count_array;
                // print_r($data2);
                // die;
                // for($x=1;$x<=$count_array;$x++)
                // {
                //     $bb = 'file_name'.$x;
                //     echo $$bb;
                // }
                // die;
            }
            else
            {
                $file_name_array = array();
            }

            // print_r($file_name->result());die;
           
            // $filename_1 = base_url($virtual_path.'/acceptance_form/one.pdf');
            // $filename_2 = base_url($virtual_path.'/acceptance_form/two.pdf');

            if(in_array('VNMA',$_SESSION['module_code']))
            {
                $notification = $this->db->query("SELECT b.*, b.query_admin as query FROM notification_modal_subscribe a INNER JOIN notification_modal b ON a.notification_guid = b.notification_guid WHERE b.isactive = 1 AND a.customer_guid = '".$this->session->userdata('customer_guid')."' ORDER BY b.seq ASC ");
            }
            else
            {
                $notification = $this->db->query("SELECT b.*, b.query_user as query FROM notification_modal_subscribe a INNER JOIN notification_modal b ON a.notification_guid = b.notification_guid WHERE b.isactive = 1 AND a.customer_guid = '".$this->session->userdata('customer_guid')."' ORDER BY b.seq ASC ");
            }

            

            $data = array(
                'pomain' => $check_outstanding_pomain->row('count_pomain'),
                'grmain' => $check_grn->row('count_doc'),
                'grda' => $check_grda->row('count_doc'),
                'no_respond' => $no_respond->row('count_pomain'),
                'date_from' => $this->db->query("SELECT curdate() - INTERVAL $dashboard_num_days_data DAY as date_from")->row('date_from'),
                'date_to' => $this->db->query("SELECT curdate()  as date_to")->row('date_to'),
                'announcement' => $announcement,
                'redirect_pomain' => $redirect_pomain,
                'redirect_grmain' => $redirect_grmain,
                'redirect_grda' => $redirect_grda,
                'show_panel' => $show_panel,
                'show_announcement_sidebar' => $show_announcement_sidebar,
                'check_announcement_acknowledgement' => $check_announcement_acknowledgement,
                // 'filename_1' => $filename_1,
                // 'filename_2' => $filename_2,
                'redirect_grmain_download' => $redirect_grmain_download,
                'mandatory' => $mandatory,
                'pdf' => $pdf,
                'virtual_path' => base_url($virtual_path),
                'file_name_array' => $file_name_array,
                'notification' => $notification
               /* 'alert' => $alert,*/
            );

            $this->load->view('header');
            $this->load->view('dashboard', $data);
            $this->load->view('dashboard_modal', $data);
            $this->load->view('footer');
        }
        else
        {
            redirect('#');
        }

    }

    public function previous_announcement()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('userid') != '' && $_SESSION['user_logs'] == $this->panda->validate_login())
        {   
            $check_announcement = $this->db->query("SELECT * from announcement where customer_guid = '".$_SESSION['customer_guid']."' and posted= '1' and now() >= publish_at and acknowledgement=0 order by publish_at desc, created_at desc limit 100 ");
            //echo $this->db->last_query();die;

            if($check_announcement->num_rows() < 1)
            {
                $announcement = $this->db->query("SELECT 'Welcome' as title, 'No New announcement at this moment' as content, curdate() as docdate ");
            }   
            else
            {
                $announcement = $check_announcement;
            }

            $data = array(
                'announcement' => $announcement,
            );

            $this->load->view('header');
            $this->load->view('announcement_preview', $data);
            $this->load->view('footer');
        }
        else
        {
            redirect('#');
        }
    }

    public function redirect_from_dashboard()
    {
        if($this->session->userdata('loginuser') == true && $this->session->userdata('userid') != '' && $_SESSION['user_logs'] == $this->panda->validate_login())
        {
            $loc = $_REQUEST['loc'];
            $mode = $_REQUEST['mode'];

            redirect("$mode"."?loc=".$loc);
        }
        else
        {
              redirect('#');
        }
    }

    public function see_more_alert()
    {
       if($this->session->userdata('loginuser') == true && $this->session->userdata('userid') != '' && $_SESSION['user_logs'] == $this->panda->validate_login())
        {
            $query_loc  = $_SESSION['query_loc'];
            $customer_guid  = $_SESSION['customer_guid'];
            
            
           // echo var_dump($query_loc);die;
        }
        else
        {
            redirect('#');
        } 
    }

    public function cust_get_ip()
    {
        $acc_guid = $_SESSION['customer_guid'];
        $ip = $this->db->query("SELECT jasper_url FROM acc WHERE acc_guid = '$acc_guid'")->row('jasper_url');
        // echo $ip;
        $output = array();

        $output['ip'] = $ip;

        echo json_encode($output);
    }


}
